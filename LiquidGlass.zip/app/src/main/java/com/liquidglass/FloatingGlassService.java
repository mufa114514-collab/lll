package com.liquidglass;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.os.IBinder;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;

public class FloatingGlassService extends Service {

    private WindowManager windowManager;
    private FrameLayout floatingRoot;
    private LiquidGlassView glassView;
    private Bitmap bgBitmap;
    private static Bitmap sharedCustomBg;
    private static int sharedBgType = 0;
    private static boolean sharedUseCustomBg = false;

    private static final String CHANNEL_ID = "liquid_glass_overlay";

    public static void setSharedBackground(int bgType, boolean useCustom, Bitmap customBg) {
        sharedBgType = bgType;
        sharedUseCustomBg = useCustom;
        if (customBg != null) {
            sharedCustomBg = customBg.copy(Bitmap.Config.ARGB_8888, false);
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        startForeground(1, buildNotification());
        windowManager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        createFloatingView();
    }

    private void createNotificationChannel() {
        NotificationChannel channel = new NotificationChannel(
            CHANNEL_ID, "Liquid Glass Overlay",
            NotificationManager.IMPORTANCE_LOW
        );
        channel.setDescription("Liquid Glass Floating Window");
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(channel);
    }

    private Notification buildNotification() {
        Intent intent = new Intent(this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        PendingIntent pi = PendingIntent.getActivity(this, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        return new Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("Liquid Glass")
            .setContentText("Floating window is active")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentIntent(pi)
            .setOngoing(true)
            .build();
    }

    private void createFloatingView() {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        float density = dm.density;
        int screenW = dm.widthPixels;
        int screenH = dm.heightPixels;

        int panelW = (int)(200 * density);
        int panelH = (int)(200 * density);

        bgBitmap = createBackgroundBitmap(screenW, screenH, density);

        floatingRoot = new FrameLayout(this) {
            @Override
            protected void onDraw(Canvas canvas) {
                super.onDraw(canvas);
            }
        };
        floatingRoot.setWillNotDraw(false);

        glassView = new LiquidGlassView(this);
        glassView.setCornerRadius(32 * density);
        glassView.setBlurRadius(25 * density);
        glassView.setRefractionHeight(60 * density);
        glassView.setRefractionAmount(24 * density);

        glassView.setBackdropProvider(new LiquidGlassView.BackdropProvider() {
            @Override
            public void drawBackdrop(Canvas canvas, int viewLeft, int viewTop, int viewWidth, int viewHeight) {
                if (bgBitmap != null && !bgBitmap.isRecycled()) {
                    canvas.save();
                    canvas.translate(-viewLeft, -viewTop);
                    canvas.drawBitmap(bgBitmap, 0, 0, null);
                    canvas.restore();
                }
            }
        });

        FrameLayout.LayoutParams glassLp = new FrameLayout.LayoutParams(panelW, panelH);
        floatingRoot.addView(glassView, glassLp);

        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
            panelW + (int)(120 * density),
            panelH + (int)(120 * density),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        );
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = (screenW - panelW) / 2;
        params.y = (screenH - panelH) / 2;

        glassView.setX(60 * density);
        glassView.setY(60 * density);

        setupDragBehavior(params, density);

        windowManager.addView(floatingRoot, params);
    }

    private void setupDragBehavior(WindowManager.LayoutParams params, float density) {
        glassView.setOnTouchListener(new View.OnTouchListener() {
            private int initialX, initialY;
            private float initialTouchX, initialTouchY;
            private boolean isDragging = false;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = params.x;
                        initialY = params.y;
                        initialTouchX = event.getRawX();
                        initialTouchY = event.getRawY();
                        isDragging = false;
                        v.animate().scaleX(0.95f).scaleY(0.95f).setDuration(120).start();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = event.getRawX() - initialTouchX;
                        float dy = event.getRawY() - initialTouchY;
                        if (Math.abs(dx) > 5 || Math.abs(dy) > 5) {
                            isDragging = true;
                        }
                        if (isDragging) {
                            params.x = initialX + (int) dx;
                            params.y = initialY + (int) dy;
                            windowManager.updateViewLayout(floatingRoot, params);
                            glassView.refreshBackdrop();
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        v.animate().scaleX(1f).scaleY(1f).setDuration(200).start();
                        if (!isDragging) {
                            stopSelf();
                        }
                        return true;
                }
                return false;
            }
        });
    }

    private Bitmap createBackgroundBitmap(int w, int h, float density) {
        if (sharedUseCustomBg && sharedCustomBg != null && !sharedCustomBg.isRecycled()) {
            float scaleX = (float) w / sharedCustomBg.getWidth();
            float scaleY = (float) h / sharedCustomBg.getHeight();
            float scale = Math.max(scaleX, scaleY);
            int newW = (int)(sharedCustomBg.getWidth() * scale);
            int newH = (int)(sharedCustomBg.getHeight() * scale);
            Bitmap scaled = Bitmap.createScaledBitmap(sharedCustomBg, newW, newH, true);
            Bitmap result = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(result);
            c.drawBitmap(scaled, (w - newW) / 2f, (h - newH) / 2f, null);
            if (scaled != sharedCustomBg) scaled.recycle();
            return result;
        }

        Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

        int[][] gradientColors = {
            {0xFF1a0533, 0xFF2d1b69, 0xFF0d47a1, 0xFF006064, 0xFF1b5e20, 0xFF33691e},
            {0xFFff6f00, 0xFFf44336, 0xFFe91e63, 0xFF9c27b0, 0xFF673ab7},
            {0xFF0d47a1, 0xFF1565c0, 0xFF0097a7, 0xFF00897b, 0xFF2e7d32}
        };

        int type = sharedBgType % gradientColors.length;
        int[] colors = gradientColors[type];

        LinearGradient lg = new LinearGradient(0, 0, w, h, colors, null, Shader.TileMode.CLAMP);
        paint.setShader(lg);
        c.drawRect(0, 0, w, h, paint);
        paint.setShader(null);

        int[][] orbPos = {{w/4, h/3, w/3}, {w*3/4, h/2, w/4}, {w/2, h*3/4, w/3}};
        int[] orbColors = {0x40e040fb, 0x4000bcd4, 0x40ff6f00};
        for (int i = 0; i < orbPos.length; i++) {
            RadialGradient rg = new RadialGradient(
                orbPos[i][0], orbPos[i][1], orbPos[i][2],
                orbColors[i], Color.TRANSPARENT, Shader.TileMode.CLAMP
            );
            paint.setShader(rg);
            c.drawCircle(orbPos[i][0], orbPos[i][1], orbPos[i][2], paint);
        }
        paint.setShader(null);

        return bmp;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (floatingRoot != null) {
            windowManager.removeView(floatingRoot);
        }
        if (bgBitmap != null) {
            bgBitmap.recycle();
        }
    }
}
