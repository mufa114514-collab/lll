package com.liquidglass;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.widget.FrameLayout;

import java.util.ArrayList;
import java.util.List;

public class LiquidGlassContainer extends FrameLayout implements LiquidGlassView.BackdropProvider {

    private Bitmap backgroundBitmap;
    private Canvas backgroundCanvas;
    private final Paint bgPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);

    private final List<LiquidGlassView> glassViews = new ArrayList<>();

    private int bgType = 0;
    private final Paint gradPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    private boolean backgroundDirty = true;

    private Bitmap customBgBitmap;
    private Bitmap scaledCustomBg;
    private boolean useCustomBg = false;

    public LiquidGlassContainer(Context context) {
        super(context);
        setWillNotDraw(false);
    }

    public void setBackgroundType(int type) {
        this.bgType = type;
        this.useCustomBg = false;
        backgroundDirty = true;
        invalidate();
        refreshAllGlass();
    }

    public void setCustomBackground(Bitmap bitmap) {
        if (bitmap == null) return;
        if (customBgBitmap != null && customBgBitmap != bitmap) {
            customBgBitmap.recycle();
        }
        if (scaledCustomBg != null) {
            scaledCustomBg.recycle();
            scaledCustomBg = null;
        }
        customBgBitmap = bitmap;
        useCustomBg = true;
        backgroundDirty = true;
        invalidate();
        refreshAllGlass();
    }

    public boolean isUseCustomBg() {
        return useCustomBg;
    }

    public int getBgType() {
        return bgType;
    }

    public void refreshAllGlass() {
        for (LiquidGlassView v : glassViews) {
            v.refreshBackdrop();
        }
    }

    public LiquidGlassView addGlassPanel(int width, int height, float x, float y) {
        LiquidGlassView glass = new LiquidGlassView(getContext());
        glass.setBackdropProvider(this);

        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(width, height);
        glass.setLayoutParams(lp);
        glass.setX(x);
        glass.setY(y);
        addView(glass);
        glassViews.add(glass);
        return glass;
    }

    public List<LiquidGlassView> getGlassViews() {
        return glassViews;
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        if (w > 0 && h > 0) {
            if (backgroundBitmap != null) backgroundBitmap.recycle();
            backgroundBitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            backgroundCanvas = new Canvas(backgroundBitmap);
            if (scaledCustomBg != null) {
                scaledCustomBg.recycle();
                scaledCustomBg = null;
            }
            backgroundDirty = true;
        }
    }

    private void renderBackground() {
        if (backgroundCanvas == null) return;
        if (!backgroundDirty) return;
        backgroundDirty = false;

        int w = getWidth();
        int h = getHeight();
        backgroundCanvas.drawColor(Color.BLACK);

        if (useCustomBg && customBgBitmap != null && !customBgBitmap.isRecycled()) {
            drawCustomBg(backgroundCanvas, w, h);
        } else {
            switch (bgType) {
                case 0:
                    drawWallpaper0(backgroundCanvas, w, h);
                    break;
                case 1:
                    drawWallpaper1(backgroundCanvas, w, h);
                    break;
                case 2:
                    drawWallpaper2(backgroundCanvas, w, h);
                    break;
                default:
                    drawWallpaper0(backgroundCanvas, w, h);
                    break;
            }
        }
    }

    private void drawCustomBg(Canvas c, int w, int h) {
        if (scaledCustomBg == null || scaledCustomBg.isRecycled()) {
            float scaleX = (float) w / customBgBitmap.getWidth();
            float scaleY = (float) h / customBgBitmap.getHeight();
            float scale = Math.max(scaleX, scaleY);
            int newW = (int)(customBgBitmap.getWidth() * scale);
            int newH = (int)(customBgBitmap.getHeight() * scale);
            scaledCustomBg = Bitmap.createScaledBitmap(customBgBitmap, newW, newH, true);
        }
        int left = (w - scaledCustomBg.getWidth()) / 2;
        int top = (h - scaledCustomBg.getHeight()) / 2;
        c.drawBitmap(scaledCustomBg, left, top, bgPaint);
    }

    private void drawWallpaper0(Canvas c, int w, int h) {
        LinearGradient lg = new LinearGradient(
            0, 0, w, h,
            new int[]{
                0xFF1a0533,
                0xFF2d1b69,
                0xFF0d47a1,
                0xFF006064,
                0xFF1b5e20,
                0xFF33691e
            },
            new float[]{0f, 0.2f, 0.4f, 0.6f, 0.8f, 1f},
            Shader.TileMode.CLAMP
        );
        gradPaint.setShader(lg);
        c.drawRect(0, 0, w, h, gradPaint);
        gradPaint.setShader(null);
        drawOrbs(c, w, h,
            new int[][]{{w/4, h/3, w/3}, {w*3/4, h/2, w/4}, {w/2, h*3/4, w/3}},
            new int[]{0x40e040fb, 0x4000bcd4, 0x40ff6f00}
        );
    }

    private void drawWallpaper1(Canvas c, int w, int h) {
        LinearGradient lg = new LinearGradient(
            0, 0, w, h,
            new int[]{
                0xFFff6f00,
                0xFFf44336,
                0xFFe91e63,
                0xFF9c27b0,
                0xFF673ab7
            },
            null,
            Shader.TileMode.CLAMP
        );
        gradPaint.setShader(lg);
        c.drawRect(0, 0, w, h, gradPaint);
        gradPaint.setShader(null);
        drawOrbs(c, w, h,
            new int[][]{{w/3, h/4, w/3}, {w*2/3, h*2/3, w/4}, {w/5, h*4/5, w/3}},
            new int[]{0x40ffeb3b, 0x40e91e63, 0x40ff9800}
        );
    }

    private void drawWallpaper2(Canvas c, int w, int h) {
        LinearGradient lg = new LinearGradient(
            0, 0, w, h,
            new int[]{
                0xFF0d47a1,
                0xFF1565c0,
                0xFF0097a7,
                0xFF00897b,
                0xFF2e7d32
            },
            null,
            Shader.TileMode.CLAMP
        );
        gradPaint.setShader(lg);
        c.drawRect(0, 0, w, h, gradPaint);
        gradPaint.setShader(null);
        drawOrbs(c, w, h,
            new int[][]{{w/2, h/4, w/3}, {w/5, h/2, w/4}, {w*4/5, h*3/4, w/3}},
            new int[]{0x4000e5ff, 0x4076ff03, 0x4018ffff}
        );

        Paint circlePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        circlePaint.setStyle(Paint.Style.STROKE);
        circlePaint.setStrokeWidth(2f);
        circlePaint.setColor(0x15FFFFFF);
        for (int i = 0; i < 8; i++) {
            float cx = (float)(Math.random() * w);
            float cy = (float)(Math.random() * h);
            float r = 40 + (float)(Math.random() * 120);
            c.drawCircle(cx, cy, r, circlePaint);
        }
    }

    private void drawOrbs(Canvas c, int w, int h, int[][] positions, int[] colors) {
        for (int i = 0; i < positions.length && i < colors.length; i++) {
            RadialGradient rg = new RadialGradient(
                positions[i][0], positions[i][1], positions[i][2],
                colors[i], Color.TRANSPARENT,
                Shader.TileMode.CLAMP
            );
            gradPaint.setShader(rg);
            c.drawCircle(positions[i][0], positions[i][1], positions[i][2], gradPaint);
        }
        gradPaint.setShader(null);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        renderBackground();
        if (backgroundBitmap != null) {
            canvas.drawBitmap(backgroundBitmap, 0, 0, bgPaint);
        }
    }

    @Override
    public void drawBackdrop(Canvas canvas, int viewLeft, int viewTop, int viewWidth, int viewHeight) {
        renderBackground();
        if (backgroundBitmap != null) {
            canvas.save();
            canvas.translate(-viewLeft, -viewTop);
            canvas.drawBitmap(backgroundBitmap, 0, 0, bgPaint);
            canvas.restore();
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (backgroundBitmap != null) {
            backgroundBitmap.recycle();
            backgroundBitmap = null;
        }
        if (scaledCustomBg != null) {
            scaledCustomBg.recycle();
            scaledCustomBg = null;
        }
    }
}
