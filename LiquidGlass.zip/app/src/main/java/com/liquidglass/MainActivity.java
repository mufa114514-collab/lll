package com.liquidglass;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.InputStream;

public class MainActivity extends Activity {

    private LiquidGlassContainer container;
    private int currentBg = 0;
    private LiquidGlassView selectedPanel;
    private LinearLayout debugPanel;
    private boolean debugVisible = false;
    private FrameLayout debugWrapper;

    private static final int PICK_IMAGE_REQUEST = 1001;
    private static final int OVERLAY_PERMISSION_REQUEST = 1002;
    private static final int STORAGE_PERMISSION_REQUEST = 1003;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().setFlags(
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        );
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
        );
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.TRANSPARENT);

        DisplayMetrics dm = getResources().getDisplayMetrics();
        float density = dm.density;
        int screenW = dm.widthPixels;
        int screenH = dm.heightPixels;

        container = new LiquidGlassContainer(this);
        container.setLayoutParams(new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        ));

        setContentView(container);

        int panelW = (int)(screenW * 0.85f);
        int panelH = (int)(200 * density);
        float startX = (screenW - panelW) / 2f;
        float startY = 120 * density;

        LiquidGlassView panel1 = container.addGlassPanel(
            panelW, panelH, startX, startY
        );

        int smallW = (int)(screenW * 0.42f);
        int smallH = (int)(180 * density);
        LiquidGlassView panel2 = container.addGlassPanel(
            smallW, smallH,
            screenW * 0.05f,
            startY + panelH + 30 * density
        );
        panel2.setCornerRadius(28 * density);
        panel2.setEnableDispersion(true);

        LiquidGlassView panel3 = container.addGlassPanel(
            smallW, smallH,
            screenW * 0.53f,
            startY + panelH + 30 * density
        );
        panel3.setCornerRadius(28 * density);
        panel3.setHighlightAngle(135f);

        int circleSize = (int)(140 * density);
        LiquidGlassView circle = container.addGlassPanel(
            circleSize, circleSize,
            (screenW - circleSize) / 2f,
            startY + panelH + smallH + 60 * density
        );
        circle.setCornerRadius(circleSize / 2f);

        int barW = (int)(screenW * 0.9f);
        int barH = (int)(64 * density);
        LiquidGlassView bottomBar = container.addGlassPanel(
            barW, barH,
            (screenW - barW) / 2f,
            screenH - 100 * density
        );
        bottomBar.setCornerRadius(32 * density);
        bottomBar.setBlurRadius(30 * density);

        selectedPanel = panel1;

        addLabels(panel1, panel2, panel3, circle, bottomBar, density);
        addToolbar(density, screenW);
        addDebugPanel(density, screenW, screenH);
    }

    private void addLabels(LiquidGlassView p1, LiquidGlassView p2, LiquidGlassView p3,
                           LiquidGlassView circ, LiquidGlassView bar, float density) {
        addLabel(p1, "Liquid Glass", 18, Typeface.BOLD);
        addLabel(p2, "Dispersion", 14, Typeface.NORMAL);
        addLabel(p3, "Highlight 135", 14, Typeface.NORMAL);
        addLabel(circ, "", 14, Typeface.NORMAL);
        addLabel(bar, "Drag any panel", 13, Typeface.NORMAL);
    }

    private void addLabel(LiquidGlassView glass, String text, int textSizeSp, int style) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextColor(Color.WHITE);
        tv.setTextSize(textSizeSp);
        tv.setTypeface(Typeface.create("sans-serif-medium", style));
        tv.setGravity(Gravity.CENTER);
        tv.setShadowLayer(4f, 0, 1, 0x40000000);

        FrameLayout wrapper = new FrameLayout(this);
        FrameLayout.LayoutParams wrapLp = new FrameLayout.LayoutParams(
            glass.getLayoutParams().width,
            glass.getLayoutParams().height
        );
        wrapper.setLayoutParams(wrapLp);
        wrapper.setX(glass.getX());
        wrapper.setY(glass.getY());

        FrameLayout.LayoutParams tvLp = new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        );
        wrapper.addView(tv, tvLp);

        wrapper.setClickable(false);
        wrapper.setFocusable(false);
        tv.setClickable(false);
        tv.setFocusable(false);

        container.addView(wrapper);

        linkPosition(glass, wrapper);
    }

    private void linkPosition(final View source, final View target) {
        source.addOnLayoutChangeListener(new View.OnLayoutChangeListener() {
            @Override
            public void onLayoutChange(View v, int l, int t, int r, int b, int ol, int ot, int or2, int ob) {
                target.setX(source.getX());
                target.setY(source.getY());
                target.setScaleX(source.getScaleX());
                target.setScaleY(source.getScaleY());
            }
        });

        source.setOnTouchListener(new View.OnTouchListener() {
            private float dX, dY;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        dX = v.getX() - event.getRawX();
                        dY = v.getY() - event.getRawY();
                        v.animate().scaleX(0.97f).scaleY(0.97f).setDuration(120).start();
                        target.animate().scaleX(0.97f).scaleY(0.97f).setDuration(120).start();
                        selectedPanel = (LiquidGlassView) v;
                        if (debugVisible) updateDebugSliders();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float newX = event.getRawX() + dX;
                        float newY = event.getRawY() + dY;
                        v.setX(newX);
                        v.setY(newY);
                        target.setX(newX);
                        target.setY(newY);
                        ((LiquidGlassView) v).refreshBackdrop();
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        v.animate().scaleX(1f).scaleY(1f).setDuration(200).start();
                        target.animate().scaleX(1f).scaleY(1f).setDuration(200).start();
                        return true;
                }
                return false;
            }
        });
    }

    private void addToolbar(float density, int screenW) {
        HorizontalScrollView scrollView = new HorizontalScrollView(this);
        scrollView.setHorizontalScrollBarEnabled(false);

        LinearLayout toolbar = new LinearLayout(this);
        toolbar.setOrientation(LinearLayout.HORIZONTAL);
        toolbar.setGravity(Gravity.CENTER_VERTICAL);
        int pad = (int)(8 * density);
        toolbar.setPadding(pad, pad, pad, pad);

        String[] labels = {"Switch BG", "Album", "Float", "Debug"};
        View.OnClickListener[] listeners = {
            v -> {
                currentBg = (currentBg + 1) % 3;
                container.setBackgroundType(currentBg);
            },
            v -> openImagePicker(),
            v -> toggleFloatingWindow(),
            v -> toggleDebugPanel()
        };

        for (int i = 0; i < labels.length; i++) {
            TextView btn = new TextView(this);
            btn.setText(labels[i]);
            btn.setTextColor(Color.WHITE);
            btn.setTextSize(11);
            btn.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
            btn.setGravity(Gravity.CENTER);
            btn.setPadding((int)(14*density), (int)(8*density), (int)(14*density), (int)(8*density));
            btn.setBackgroundColor(0x40FFFFFF);
            LinearLayout.LayoutParams btnLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            );
            btnLp.setMargins((int)(4*density), 0, (int)(4*density), 0);
            btn.setLayoutParams(btnLp);
            btn.setOnClickListener(listeners[i]);
            toolbar.addView(btn);
        }

        scrollView.addView(toolbar);

        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT
        );
        lp.gravity = Gravity.TOP | Gravity.END;
        lp.topMargin = (int)(48 * density);
        lp.rightMargin = (int)(8 * density);
        scrollView.setLayoutParams(lp);

        container.addView(scrollView);
    }

    private SeekBar seekCornerRadius, seekBlurRadius, seekRefractionHeight, seekRefractionAmount;
    private SeekBar seekHighlightAngle, seekHighlightAlpha, seekShadowAlpha, seekInnerShadowAlpha;
    private SeekBar seekSaturation, seekBrightness, seekHighlightFalloff, seekShadowRadius;
    private TextView tvCornerRadius, tvBlurRadius, tvRefractionHeight, tvRefractionAmount;
    private TextView tvHighlightAngle, tvHighlightAlpha, tvShadowAlpha, tvInnerShadowAlpha;
    private TextView tvSaturation, tvBrightness, tvHighlightFalloff, tvShadowRadius;

    private void addDebugPanel(float density, int screenW, int screenH) {
        debugWrapper = new FrameLayout(this);
        debugWrapper.setVisibility(View.GONE);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(false);

        debugPanel = new LinearLayout(this);
        debugPanel.setOrientation(LinearLayout.VERTICAL);
        debugPanel.setBackgroundColor(0xCC1a1a2e);
        int pad = (int)(16 * density);
        debugPanel.setPadding(pad, pad, pad, pad + (int)(80 * density));

        seekCornerRadius = addSlider("Corner Radius", 0, 200, 32, density);
        tvCornerRadius = lastLabel;
        seekBlurRadius = addSlider("Blur Radius", 0, 100, 25, density);
        tvBlurRadius = lastLabel;
        seekRefractionHeight = addSlider("Refraction Height", 0, 200, 60, density);
        tvRefractionHeight = lastLabel;
        seekRefractionAmount = addSlider("Refraction Amount", 0, 100, 24, density);
        tvRefractionAmount = lastLabel;
        seekHighlightAngle = addSlider("Highlight Angle", 0, 360, 45, density);
        tvHighlightAngle = lastLabel;
        seekHighlightAlpha = addSlider("Highlight Alpha", 0, 100, 50, density);
        tvHighlightAlpha = lastLabel;
        seekHighlightFalloff = addSlider("Highlight Falloff", 1, 100, 10, density);
        tvHighlightFalloff = lastLabel;
        seekShadowAlpha = addSlider("Shadow Alpha", 0, 100, 10, density);
        tvShadowAlpha = lastLabel;
        seekShadowRadius = addSlider("Shadow Radius", 0, 100, 24, density);
        tvShadowRadius = lastLabel;
        seekInnerShadowAlpha = addSlider("Inner Shadow Alpha", 0, 100, 15, density);
        tvInnerShadowAlpha = lastLabel;
        seekSaturation = addSlider("Saturation", 0, 300, 150, density);
        tvSaturation = lastLabel;
        seekBrightness = addSlider("Brightness", 0, 200, 100, density);
        tvBrightness = lastLabel;

        addToggleRow("Depth Effect", true, density);
        addToggleRow("Dispersion", false, density);

        scroll.addView(debugPanel);

        FrameLayout.LayoutParams wrapperLp = new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            (int)(screenH * 0.45f)
        );
        wrapperLp.gravity = Gravity.BOTTOM;
        debugWrapper.setLayoutParams(wrapperLp);
        debugWrapper.addView(scroll, new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        ));

        container.addView(debugWrapper);

        setupSliderListeners(density);
    }

    private TextView lastLabel;

    private SeekBar addSlider(String name, int min, int max, int defaultVal, float density) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        int margin = (int)(6 * density);
        LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        rowLp.setMargins(0, margin, 0, margin);
        row.setLayoutParams(rowLp);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);

        TextView label = new TextView(this);
        label.setText(name);
        label.setTextColor(0xFFCCCCCC);
        label.setTextSize(12);
        LinearLayout.LayoutParams labelLp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        label.setLayoutParams(labelLp);

        TextView valueLabel = new TextView(this);
        valueLabel.setText(String.valueOf(defaultVal));
        valueLabel.setTextColor(0xFF00E5FF);
        valueLabel.setTextSize(12);
        valueLabel.setGravity(Gravity.END);
        lastLabel = valueLabel;

        header.addView(label);
        header.addView(valueLabel);
        row.addView(header);

        SeekBar seekBar = new SeekBar(this);
        seekBar.setMin(min);
        seekBar.setMax(max);
        seekBar.setProgress(defaultVal);
        seekBar.setMinimumHeight((int)(32 * density));
        row.addView(seekBar);

        debugPanel.addView(row);
        return seekBar;
    }

    private void addToggleRow(String name, boolean defaultOn, float density) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        int margin = (int)(6 * density);
        LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        rowLp.setMargins(0, margin, 0, margin);
        row.setLayoutParams(rowLp);

        TextView label = new TextView(this);
        label.setText(name);
        label.setTextColor(0xFFCCCCCC);
        label.setTextSize(12);
        LinearLayout.LayoutParams labelLp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        label.setLayoutParams(labelLp);

        TextView toggle = new TextView(this);
        toggle.setText(defaultOn ? "ON" : "OFF");
        toggle.setTextColor(defaultOn ? 0xFF00E5FF : 0xFF888888);
        toggle.setTextSize(12);
        toggle.setTypeface(Typeface.DEFAULT_BOLD);
        toggle.setPadding((int)(12*density), (int)(6*density), (int)(12*density), (int)(6*density));
        toggle.setBackgroundColor(0x30FFFFFF);
        toggle.setGravity(Gravity.CENTER);

        toggle.setOnClickListener(v -> {
            boolean isOn = toggle.getText().toString().equals("ON");
            boolean newState = !isOn;
            toggle.setText(newState ? "ON" : "OFF");
            toggle.setTextColor(newState ? 0xFF00E5FF : 0xFF888888);
            if (selectedPanel != null) {
                if (name.equals("Depth Effect")) {
                    selectedPanel.setEnableDepthEffect(newState);
                } else if (name.equals("Dispersion")) {
                    selectedPanel.setEnableDispersion(newState);
                }
            }
        });

        row.addView(label);
        row.addView(toggle);
        debugPanel.addView(row);
    }

    private void setupSliderListeners(float density) {
        SeekBar.OnSeekBarChangeListener listener = new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (!fromUser || selectedPanel == null) return;

                if (seekBar == seekCornerRadius) {
                    selectedPanel.setCornerRadius(progress * density);
                    tvCornerRadius.setText(String.valueOf(progress));
                } else if (seekBar == seekBlurRadius) {
                    selectedPanel.setBlurRadius(progress * density);
                    tvBlurRadius.setText(String.valueOf(progress));
                } else if (seekBar == seekRefractionHeight) {
                    selectedPanel.setRefractionHeight(progress * density);
                    tvRefractionHeight.setText(String.valueOf(progress));
                } else if (seekBar == seekRefractionAmount) {
                    selectedPanel.setRefractionAmount(progress * density);
                    tvRefractionAmount.setText(String.valueOf(progress));
                } else if (seekBar == seekHighlightAngle) {
                    selectedPanel.setHighlightAngle(progress);
                    tvHighlightAngle.setText(String.valueOf(progress));
                } else if (seekBar == seekHighlightAlpha) {
                    selectedPanel.setHighlightAlpha(progress / 100f);
                    tvHighlightAlpha.setText(String.valueOf(progress));
                } else if (seekBar == seekHighlightFalloff) {
                    selectedPanel.setHighlightFalloff(progress / 10f);
                    tvHighlightFalloff.setText(String.valueOf(progress));
                } else if (seekBar == seekShadowAlpha) {
                    selectedPanel.setShadowAlpha(progress / 100f);
                    tvShadowAlpha.setText(String.valueOf(progress));
                } else if (seekBar == seekShadowRadius) {
                    selectedPanel.setShadowRadius(progress * density);
                    tvShadowRadius.setText(String.valueOf(progress));
                } else if (seekBar == seekInnerShadowAlpha) {
                    selectedPanel.setInnerShadowAlpha(progress / 100f);
                    tvInnerShadowAlpha.setText(String.valueOf(progress));
                } else if (seekBar == seekSaturation) {
                    selectedPanel.setSaturation(progress / 100f);
                    tvSaturation.setText(String.valueOf(progress));
                } else if (seekBar == seekBrightness) {
                    selectedPanel.setBrightness((progress - 100) / 100f);
                    tvBrightness.setText(String.valueOf(progress));
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        };

        seekCornerRadius.setOnSeekBarChangeListener(listener);
        seekBlurRadius.setOnSeekBarChangeListener(listener);
        seekRefractionHeight.setOnSeekBarChangeListener(listener);
        seekRefractionAmount.setOnSeekBarChangeListener(listener);
        seekHighlightAngle.setOnSeekBarChangeListener(listener);
        seekHighlightAlpha.setOnSeekBarChangeListener(listener);
        seekHighlightFalloff.setOnSeekBarChangeListener(listener);
        seekShadowAlpha.setOnSeekBarChangeListener(listener);
        seekShadowRadius.setOnSeekBarChangeListener(listener);
        seekInnerShadowAlpha.setOnSeekBarChangeListener(listener);
        seekSaturation.setOnSeekBarChangeListener(listener);
        seekBrightness.setOnSeekBarChangeListener(listener);
    }

    private void updateDebugSliders() {
        if (selectedPanel == null) return;
        float density = getResources().getDisplayMetrics().density;

        seekCornerRadius.setProgress((int)(selectedPanel.getCornerRadius() / density));
        seekBlurRadius.setProgress((int)(selectedPanel.getBlurRadius() / density));
        seekRefractionHeight.setProgress((int)(selectedPanel.getRefractionHeight() / density));
        seekRefractionAmount.setProgress((int)(selectedPanel.getRefractionAmount() / density));
        seekHighlightAngle.setProgress((int) selectedPanel.getHighlightAngle());
        seekHighlightAlpha.setProgress((int)(selectedPanel.getHighlightAlpha() * 100));
        seekHighlightFalloff.setProgress((int)(selectedPanel.getHighlightFalloff() * 10));
        seekShadowAlpha.setProgress((int)(selectedPanel.getShadowAlpha() * 100));
        seekShadowRadius.setProgress((int)(selectedPanel.getShadowRadius() / density));
        seekInnerShadowAlpha.setProgress((int)(selectedPanel.getInnerShadowAlpha() * 100));
        seekSaturation.setProgress((int)(selectedPanel.getSaturation() * 100));
        seekBrightness.setProgress((int)(selectedPanel.getBrightness() * 100) + 100);

        tvCornerRadius.setText(String.valueOf(seekCornerRadius.getProgress()));
        tvBlurRadius.setText(String.valueOf(seekBlurRadius.getProgress()));
        tvRefractionHeight.setText(String.valueOf(seekRefractionHeight.getProgress()));
        tvRefractionAmount.setText(String.valueOf(seekRefractionAmount.getProgress()));
        tvHighlightAngle.setText(String.valueOf(seekHighlightAngle.getProgress()));
        tvHighlightAlpha.setText(String.valueOf(seekHighlightAlpha.getProgress()));
        tvHighlightFalloff.setText(String.valueOf(seekHighlightFalloff.getProgress()));
        tvShadowAlpha.setText(String.valueOf(seekShadowAlpha.getProgress()));
        tvShadowRadius.setText(String.valueOf(seekShadowRadius.getProgress()));
        tvInnerShadowAlpha.setText(String.valueOf(seekInnerShadowAlpha.getProgress()));
        tvSaturation.setText(String.valueOf(seekSaturation.getProgress()));
        tvBrightness.setText(String.valueOf(seekBrightness.getProgress()));
    }

    private void toggleDebugPanel() {
        debugVisible = !debugVisible;
        debugWrapper.setVisibility(debugVisible ? View.VISIBLE : View.GONE);
        if (debugVisible) {
            updateDebugSliders();
        }
    }

    private void openImagePicker() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (checkSelfPermission(Manifest.permission.READ_MEDIA_IMAGES) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.READ_MEDIA_IMAGES}, STORAGE_PERMISSION_REQUEST);
                return;
            }
        } else {
            if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, STORAGE_PERMISSION_REQUEST);
                return;
            }
        }
        launchImagePicker();
    }

    private void launchImagePicker() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        intent.setType("image/*");
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }

    private void toggleFloatingWindow() {
        if (!Settings.canDrawOverlays(this)) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + getPackageName()));
            startActivityForResult(intent, OVERLAY_PERMISSION_REQUEST);
            Toast.makeText(this, "Please allow overlay permission", Toast.LENGTH_SHORT).show();
            return;
        }
        startFloatingService();
    }

    private void startFloatingService() {
        FloatingGlassService.setSharedBackground(
            container.getBgType(),
            container.isUseCustomBg(),
            null
        );
        Intent intent = new Intent(this, FloatingGlassService.class);
        startForegroundService(intent);
        Toast.makeText(this, "Floating window started, tap to close", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null) {
            Uri imageUri = data.getData();
            if (imageUri != null) {
                try {
                    InputStream inputStream = getContentResolver().openInputStream(imageUri);
                    BitmapFactory.Options opts = new BitmapFactory.Options();
                    opts.inPreferredConfig = Bitmap.Config.ARGB_8888;
                    Bitmap bitmap = BitmapFactory.decodeStream(inputStream, null, opts);
                    inputStream.close();
                    if (bitmap != null) {
                        int maxDim = 2048;
                        if (bitmap.getWidth() > maxDim || bitmap.getHeight() > maxDim) {
                            float scale = (float) maxDim / Math.max(bitmap.getWidth(), bitmap.getHeight());
                            Bitmap scaled = Bitmap.createScaledBitmap(bitmap,
                                (int)(bitmap.getWidth() * scale),
                                (int)(bitmap.getHeight() * scale), true);
                            bitmap.recycle();
                            bitmap = scaled;
                        }
                        container.setCustomBackground(bitmap);
                        Toast.makeText(this, "Background updated", Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e) {
                    Toast.makeText(this, "Failed to load image", Toast.LENGTH_SHORT).show();
                }
            }
        } else if (requestCode == OVERLAY_PERMISSION_REQUEST) {
            if (Settings.canDrawOverlays(this)) {
                startFloatingService();
            } else {
                Toast.makeText(this, "Overlay permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == STORAGE_PERMISSION_REQUEST) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                launchImagePicker();
            } else {
                Toast.makeText(this, "Storage permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
