package com.liquidglass;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RectF;
import android.graphics.RenderEffect;
import android.graphics.RenderNode;
import android.graphics.RuntimeShader;
import android.view.View;

public class LiquidGlassView extends View {

    private static final String REFRACTION_SHADER_SRC =
        "uniform shader content;\n" +
        "uniform float2 size;\n" +
        "uniform float2 offset;\n" +
        "uniform float4 cornerRadii;\n" +
        "uniform float refractionHeight;\n" +
        "uniform float refractionAmount;\n" +
        "uniform float depthEffect;\n" +
        "\n" +
        "float radiusAt(float2 coord, float4 radii) {\n" +
        "    if (coord.x >= 0.0) {\n" +
        "        if (coord.y <= 0.0) return radii.y;\n" +
        "        else return radii.z;\n" +
        "    } else {\n" +
        "        if (coord.y <= 0.0) return radii.x;\n" +
        "        else return radii.w;\n" +
        "    }\n" +
        "}\n" +
        "\n" +
        "float sdRoundedRect(float2 coord, float2 halfSize, float radius) {\n" +
        "    float2 cornerCoord = abs(coord) - (halfSize - float2(radius));\n" +
        "    float outside = length(max(cornerCoord, 0.0)) - radius;\n" +
        "    float inside = min(max(cornerCoord.x, cornerCoord.y), 0.0);\n" +
        "    return outside + inside;\n" +
        "}\n" +
        "\n" +
        "float2 gradSdRoundedRect(float2 coord, float2 halfSize, float radius) {\n" +
        "    float2 cornerCoord = abs(coord) - (halfSize - float2(radius));\n" +
        "    if (cornerCoord.x >= 0.0 || cornerCoord.y >= 0.0) {\n" +
        "        return sign(coord) * normalize(max(cornerCoord, 0.0));\n" +
        "    } else {\n" +
        "        float gradX = step(cornerCoord.y, cornerCoord.x);\n" +
        "        return sign(coord) * float2(gradX, 1.0 - gradX);\n" +
        "    }\n" +
        "}\n" +
        "\n" +
        "float circleMap(float x) {\n" +
        "    return 1.0 - sqrt(1.0 - x * x);\n" +
        "}\n" +
        "\n" +
        "half4 main(float2 coord) {\n" +
        "    float2 halfSize = size * 0.5;\n" +
        "    float2 centeredCoord = (coord + offset) - halfSize;\n" +
        "    float radius = radiusAt(centeredCoord, cornerRadii);\n" +
        "    \n" +
        "    float sd = sdRoundedRect(centeredCoord, halfSize, radius);\n" +
        "    if (-sd >= refractionHeight) {\n" +
        "        return content.eval(coord);\n" +
        "    }\n" +
        "    sd = min(sd, 0.0);\n" +
        "    \n" +
        "    float d = circleMap(1.0 - -sd / refractionHeight) * refractionAmount;\n" +
        "    float gradRadius = min(radius * 1.5, min(halfSize.x, halfSize.y));\n" +
        "    float2 grad = normalize(gradSdRoundedRect(centeredCoord, halfSize, gradRadius) + depthEffect * normalize(centeredCoord));\n" +
        "    \n" +
        "    float2 refractedCoord = coord + d * grad;\n" +
        "    return content.eval(refractedCoord);\n" +
        "}\n";

    private static final String DISPERSION_SHADER_SRC =
        "uniform shader content;\n" +
        "uniform float2 size;\n" +
        "uniform float2 offset;\n" +
        "uniform float4 cornerRadii;\n" +
        "uniform float refractionHeight;\n" +
        "uniform float refractionAmount;\n" +
        "uniform float depthEffect;\n" +
        "uniform float chromaticAberration;\n" +
        "\n" +
        "float radiusAt(float2 coord, float4 radii) {\n" +
        "    if (coord.x >= 0.0) {\n" +
        "        if (coord.y <= 0.0) return radii.y;\n" +
        "        else return radii.z;\n" +
        "    } else {\n" +
        "        if (coord.y <= 0.0) return radii.x;\n" +
        "        else return radii.w;\n" +
        "    }\n" +
        "}\n" +
        "\n" +
        "float sdRoundedRect(float2 coord, float2 halfSize, float radius) {\n" +
        "    float2 cornerCoord = abs(coord) - (halfSize - float2(radius));\n" +
        "    float outside = length(max(cornerCoord, 0.0)) - radius;\n" +
        "    float inside = min(max(cornerCoord.x, cornerCoord.y), 0.0);\n" +
        "    return outside + inside;\n" +
        "}\n" +
        "\n" +
        "float2 gradSdRoundedRect(float2 coord, float2 halfSize, float radius) {\n" +
        "    float2 cornerCoord = abs(coord) - (halfSize - float2(radius));\n" +
        "    if (cornerCoord.x >= 0.0 || cornerCoord.y >= 0.0) {\n" +
        "        return sign(coord) * normalize(max(cornerCoord, 0.0));\n" +
        "    } else {\n" +
        "        float gradX = step(cornerCoord.y, cornerCoord.x);\n" +
        "        return sign(coord) * float2(gradX, 1.0 - gradX);\n" +
        "    }\n" +
        "}\n" +
        "\n" +
        "float circleMap(float x) {\n" +
        "    return 1.0 - sqrt(1.0 - x * x);\n" +
        "}\n" +
        "\n" +
        "half4 main(float2 coord) {\n" +
        "    float2 halfSize = size * 0.5;\n" +
        "    float2 centeredCoord = (coord + offset) - halfSize;\n" +
        "    float radius = radiusAt(centeredCoord, cornerRadii);\n" +
        "    \n" +
        "    float sd = sdRoundedRect(centeredCoord, halfSize, radius);\n" +
        "    if (-sd >= refractionHeight) {\n" +
        "        return content.eval(coord);\n" +
        "    }\n" +
        "    sd = min(sd, 0.0);\n" +
        "    \n" +
        "    float d = circleMap(1.0 - -sd / refractionHeight) * refractionAmount;\n" +
        "    float gradRadius = min(radius * 1.5, min(halfSize.x, halfSize.y));\n" +
        "    float2 grad = normalize(gradSdRoundedRect(centeredCoord, halfSize, gradRadius) + depthEffect * normalize(centeredCoord));\n" +
        "    \n" +
        "    float2 refractedCoord = coord + d * grad;\n" +
        "    float dispersionIntensity = chromaticAberration * ((centeredCoord.x * centeredCoord.y) / (halfSize.x * halfSize.y));\n" +
        "    float2 dispersedCoord = d * grad * dispersionIntensity;\n" +
        "    \n" +
        "    half4 color = half4(0.0);\n" +
        "    \n" +
        "    half4 red = content.eval(refractedCoord + dispersedCoord);\n" +
        "    color.r += red.r / 3.5;\n" +
        "    color.a += red.a / 7.0;\n" +
        "    \n" +
        "    half4 orange = content.eval(refractedCoord + dispersedCoord * (2.0 / 3.0));\n" +
        "    color.r += orange.r / 3.5;\n" +
        "    color.g += orange.g / 7.0;\n" +
        "    color.a += orange.a / 7.0;\n" +
        "    \n" +
        "    half4 yellow = content.eval(refractedCoord + dispersedCoord * (1.0 / 3.0));\n" +
        "    color.r += yellow.r / 3.5;\n" +
        "    color.g += yellow.g / 3.5;\n" +
        "    color.a += yellow.a / 7.0;\n" +
        "    \n" +
        "    half4 green = content.eval(refractedCoord);\n" +
        "    color.g += green.g / 3.5;\n" +
        "    color.a += green.a / 7.0;\n" +
        "    \n" +
        "    half4 cyan = content.eval(refractedCoord - dispersedCoord * (1.0 / 3.0));\n" +
        "    color.g += cyan.g / 3.5;\n" +
        "    color.b += cyan.b / 3.0;\n" +
        "    color.a += cyan.a / 7.0;\n" +
        "    \n" +
        "    half4 blue = content.eval(refractedCoord - dispersedCoord * (2.0 / 3.0));\n" +
        "    color.b += blue.b / 3.0;\n" +
        "    color.a += blue.a / 7.0;\n" +
        "    \n" +
        "    half4 purple = content.eval(refractedCoord - dispersedCoord);\n" +
        "    color.r += purple.r / 7.0;\n" +
        "    color.b += purple.b / 3.0;\n" +
        "    color.a += purple.a / 7.0;\n" +
        "    \n" +
        "    return color;\n" +
        "}\n";

    private static final String HIGHLIGHT_SHADER_SRC =
        "uniform float2 size;\n" +
        "uniform float4 cornerRadii;\n" +
        "layout(color) uniform half4 color;\n" +
        "uniform float angle;\n" +
        "uniform float falloff;\n" +
        "\n" +
        "float radiusAt(float2 coord, float4 radii) {\n" +
        "    if (coord.x >= 0.0) {\n" +
        "        if (coord.y <= 0.0) return radii.y;\n" +
        "        else return radii.z;\n" +
        "    } else {\n" +
        "        if (coord.y <= 0.0) return radii.x;\n" +
        "        else return radii.w;\n" +
        "    }\n" +
        "}\n" +
        "\n" +
        "float sdRoundedRect(float2 coord, float2 halfSize, float radius) {\n" +
        "    float2 cornerCoord = abs(coord) - (halfSize - float2(radius));\n" +
        "    float outside = length(max(cornerCoord, 0.0)) - radius;\n" +
        "    float inside = min(max(cornerCoord.x, cornerCoord.y), 0.0);\n" +
        "    return outside + inside;\n" +
        "}\n" +
        "\n" +
        "float2 gradSdRoundedRect(float2 coord, float2 halfSize, float radius) {\n" +
        "    float2 cornerCoord = abs(coord) - (halfSize - float2(radius));\n" +
        "    if (cornerCoord.x >= 0.0 || cornerCoord.y >= 0.0) {\n" +
        "        return sign(coord) * normalize(max(cornerCoord, 0.0));\n" +
        "    } else {\n" +
        "        float gradX = step(cornerCoord.y, cornerCoord.x);\n" +
        "        return sign(coord) * float2(gradX, 1.0 - gradX);\n" +
        "    }\n" +
        "}\n" +
        "\n" +
        "half4 main(float2 coord) {\n" +
        "    float2 halfSize = size * 0.5;\n" +
        "    float2 centeredCoord = coord - halfSize;\n" +
        "    float radius = radiusAt(centeredCoord, cornerRadii);\n" +
        "    \n" +
        "    float gradRadius = min(radius * 1.5, min(halfSize.x, halfSize.y));\n" +
        "    float2 grad = gradSdRoundedRect(centeredCoord, halfSize, gradRadius);\n" +
        "    float2 normal = float2(cos(angle), sin(angle));\n" +
        "    float d = dot(grad, normal);\n" +
        "    float intensity = pow(abs(d), falloff);\n" +
        "    return color * intensity;\n" +
        "}\n";

    private float cornerRadius;
    private float refractionHeight;
    private float refractionAmount;
    private float blurRadius;
    private boolean enableDepthEffect;
    private boolean enableDispersion;
    private float highlightAlpha;
    private float highlightAngle;
    private float highlightFalloff;
    private float highlightWidth;
    private float highlightBlurRadius;
    private float shadowRadius;
    private float shadowOffsetX;
    private float shadowOffsetY;
    private int shadowColor;
    private float shadowAlpha;
    private float innerShadowRadius;
    private float innerShadowOffsetX;
    private float innerShadowOffsetY;
    private int innerShadowColor;
    private float innerShadowAlpha;
    private float saturation;
    private float brightness;

    private RuntimeShader refractionShader;
    private RuntimeShader dispersionShader;
    private RuntimeShader highlightShader;

    private final Paint backdropPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final Paint highlightPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint shadowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint innerShadowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint innerShadowMaskPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint surfacePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint clearPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    private final Path clipPath = new Path();
    private final RectF boundsRect = new RectF();

    private Bitmap backdropBitmap;
    private Canvas backdropCanvas;

    private RenderNode backdropRenderNode;
    private RenderNode highlightRenderNode;
    private RenderNode innerShadowRenderNode;

    private BackdropProvider backdropProvider;

    public interface BackdropProvider {
        void drawBackdrop(Canvas canvas, int viewLeft, int viewTop, int viewWidth, int viewHeight);
    }

    public LiquidGlassView(Context context) {
        super(context);
        float density = context.getResources().getDisplayMetrics().density;
        cornerRadius = 32f * density;
        refractionHeight = 60f * density;
        refractionAmount = 24f * density;
        blurRadius = 25f * density;
        enableDepthEffect = true;
        enableDispersion = false;
        highlightAlpha = 0.5f;
        highlightAngle = 45f;
        highlightFalloff = 1f;
        highlightWidth = 0.5f * density;
        highlightBlurRadius = 0.25f * density;
        shadowRadius = 24f * density;
        shadowOffsetX = 0f;
        shadowOffsetY = 4f * density;
        shadowColor = Color.BLACK;
        shadowAlpha = 0.1f;
        innerShadowRadius = 24f * density;
        innerShadowOffsetX = 0f;
        innerShadowOffsetY = 24f * density;
        innerShadowColor = Color.BLACK;
        innerShadowAlpha = 0.15f;
        saturation = 1.5f;
        brightness = 0f;

        setLayerType(LAYER_TYPE_HARDWARE, null);

        refractionShader = new RuntimeShader(REFRACTION_SHADER_SRC);
        dispersionShader = new RuntimeShader(DISPERSION_SHADER_SRC);
        highlightShader = new RuntimeShader(HIGHLIGHT_SHADER_SRC);

        innerShadowMaskPaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.CLEAR));
        clearPaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.CLEAR));
        clearPaint.setColor(Color.WHITE);

        highlightPaint.setStyle(Paint.Style.STROKE);

        backdropRenderNode = new RenderNode("backdrop");
        highlightRenderNode = new RenderNode("highlight");
        innerShadowRenderNode = new RenderNode("innerShadow");
    }

    public void setBackdropProvider(BackdropProvider provider) {
        this.backdropProvider = provider;
    }

    public void setCornerRadius(float radius) {
        this.cornerRadius = radius;
        invalidate();
    }

    public float getCornerRadius() {
        return cornerRadius;
    }

    public void setRefractionHeight(float height) {
        this.refractionHeight = height;
        rebuildBackdropBitmap();
        invalidate();
    }

    public float getRefractionHeight() {
        return refractionHeight;
    }

    public void setRefractionAmount(float amount) {
        this.refractionAmount = amount;
        invalidate();
    }

    public float getRefractionAmount() {
        return refractionAmount;
    }

    public void setBlurRadius(float radius) {
        this.blurRadius = radius;
        rebuildBackdropBitmap();
        invalidate();
    }

    public float getBlurRadius() {
        return blurRadius;
    }

    public void setEnableDepthEffect(boolean enable) {
        this.enableDepthEffect = enable;
        invalidate();
    }

    public boolean isEnableDepthEffect() {
        return enableDepthEffect;
    }

    public void setEnableDispersion(boolean enable) {
        this.enableDispersion = enable;
        invalidate();
    }

    public boolean isEnableDispersion() {
        return enableDispersion;
    }

    public void setHighlightAlpha(float alpha) {
        this.highlightAlpha = alpha;
        invalidate();
    }

    public float getHighlightAlpha() {
        return highlightAlpha;
    }

    public void setHighlightAngle(float angle) {
        this.highlightAngle = angle;
        invalidate();
    }

    public float getHighlightAngle() {
        return highlightAngle;
    }

    public void setShadowAlpha(float alpha) {
        this.shadowAlpha = alpha;
        invalidate();
    }

    public float getShadowAlpha() {
        return shadowAlpha;
    }

    public void setShadowRadius(float radius) {
        this.shadowRadius = radius;
        invalidate();
    }

    public float getShadowRadius() {
        return shadowRadius;
    }

    public void setInnerShadowAlpha(float alpha) {
        this.innerShadowAlpha = alpha;
        invalidate();
    }

    public float getInnerShadowAlpha() {
        return innerShadowAlpha;
    }

    public void setInnerShadowRadius(float radius) {
        this.innerShadowRadius = radius;
        invalidate();
    }

    public float getInnerShadowRadius() {
        return innerShadowRadius;
    }

    public void setSaturation(float saturation) {
        this.saturation = saturation;
        invalidate();
    }

    public float getSaturation() {
        return saturation;
    }

    public void setBrightness(float brightness) {
        this.brightness = brightness;
        invalidate();
    }

    public float getBrightness() {
        return brightness;
    }

    public void setHighlightFalloff(float falloff) {
        this.highlightFalloff = falloff;
        invalidate();
    }

    public float getHighlightFalloff() {
        return highlightFalloff;
    }

    public void setHighlightWidth(float width) {
        this.highlightWidth = width;
        invalidate();
    }

    public float getHighlightWidth() {
        return highlightWidth;
    }

    private void rebuildBackdropBitmap() {
        int w = getWidth();
        int h = getHeight();
        if (w > 0 && h > 0) {
            int pad = getPadding();
            int bw = w + pad * 2;
            int bh = h + pad * 2;
            if (backdropBitmap != null) backdropBitmap.recycle();
            backdropBitmap = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888);
            backdropCanvas = new Canvas(backdropBitmap);
        }
    }

    private int getPadding() {
        return (int)(Math.max(refractionHeight, 1f) + Math.max(blurRadius, 1f));
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        if (w > 0 && h > 0) {
            rebuildBackdropBitmap();
        }
    }

    private void captureBackdrop() {
        if (backdropBitmap == null || backdropProvider == null) return;
        int w = getWidth();
        int h = getHeight();
        if (w <= 0 || h <= 0) return;

        int pad = getPadding();
        backdropBitmap.eraseColor(Color.TRANSPARENT);

        int[] location = new int[2];
        getLocationInWindow(location);
        int viewLeft = location[0] - pad;
        int viewTop = location[1] - pad;

        backdropCanvas.save();
        backdropProvider.drawBackdrop(backdropCanvas, viewLeft, viewTop, backdropBitmap.getWidth(), backdropBitmap.getHeight());
        backdropCanvas.restore();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        int w = getWidth();
        int h = getHeight();
        if (w <= 0 || h <= 0) return;

        captureBackdrop();

        drawDropShadow(canvas, w, h);
        drawBackdropEffect(canvas, w, h);
        drawSurface(canvas, w, h);
        drawInnerShadow(canvas, w, h);
        drawHighlight(canvas, w, h);
    }

    private void drawDropShadow(Canvas canvas, int w, int h) {
        if (shadowAlpha <= 0f || shadowRadius <= 0f) return;

        float sr = shadowRadius;
        shadowPaint.setColor(shadowColor);
        shadowPaint.setAlpha((int)(shadowAlpha * 255));
        shadowPaint.setMaskFilter(new BlurMaskFilter(sr, BlurMaskFilter.Blur.NORMAL));

        float left = -sr * 2 + Math.min(0, shadowOffsetX);
        float top = -sr * 2 + Math.min(0, shadowOffsetY);
        float right = w + sr * 2 + Math.max(0, shadowOffsetX);
        float bottom = h + sr * 2 + Math.max(0, shadowOffsetY);

        int saveCount = canvas.saveLayer(left, top, right, bottom, null);

        boundsRect.set(0, 0, w, h);
        canvas.save();
        canvas.translate(shadowOffsetX, shadowOffsetY);
        canvas.drawRoundRect(boundsRect, cornerRadius, cornerRadius, shadowPaint);
        canvas.restore();

        canvas.drawRoundRect(boundsRect, cornerRadius, cornerRadius, clearPaint);

        canvas.restoreToCount(saveCount);
    }

    private void drawBackdropEffect(Canvas canvas, int w, int h) {
        if (backdropBitmap == null) return;

        int pad = getPadding();
        float effectiveBlur = Math.max(blurRadius, 0.001f);

        RuntimeShader shader = enableDispersion ? dispersionShader : refractionShader;
        shader.setFloatUniform("size", (float) w, (float) h);
        shader.setFloatUniform("offset", (float) -pad, (float) -pad);
        shader.setFloatUniform("cornerRadii", cornerRadius, cornerRadius, cornerRadius, cornerRadius);
        shader.setFloatUniform("refractionHeight", Math.max(refractionHeight, 0.001f));
        shader.setFloatUniform("refractionAmount", -refractionAmount);
        shader.setFloatUniform("depthEffect", enableDepthEffect ? 1f : 0f);
        if (enableDispersion) {
            dispersionShader.setFloatUniform("chromaticAberration", 1f);
        }

        RenderEffect bitmapEffect = RenderEffect.createBitmapEffect(backdropBitmap);

        RenderEffect blurredBitmap = RenderEffect.createBlurEffect(
            effectiveBlur, effectiveBlur,
            bitmapEffect,
            android.graphics.Shader.TileMode.CLAMP
        );

        ColorMatrix vibrancyMatrix = createColorControlsMatrix(brightness, 1f, saturation);
        RenderEffect colorEffect = RenderEffect.createColorFilterEffect(
            new ColorMatrixColorFilter(vibrancyMatrix),
            blurredBitmap
        );

        RenderEffect refractionEffect = RenderEffect.createRuntimeShaderEffect(shader, "content");
        RenderEffect chainedEffect = RenderEffect.createChainEffect(refractionEffect, colorEffect);

        int nodeW = w + pad * 2;
        int nodeH = h + pad * 2;
        backdropRenderNode.setPosition(0, 0, nodeW, nodeH);
        backdropRenderNode.setRenderEffect(chainedEffect);

        Canvas nodeCanvas = backdropRenderNode.beginRecording(nodeW, nodeH);
        nodeCanvas.drawBitmap(backdropBitmap, 0, 0, backdropPaint);
        backdropRenderNode.endRecording();

        canvas.save();
        boundsRect.set(0, 0, w, h);
        clipPath.reset();
        clipPath.addRoundRect(boundsRect, cornerRadius, cornerRadius, Path.Direction.CW);
        canvas.clipPath(clipPath);
        canvas.translate(-pad, -pad);
        canvas.drawRenderNode(backdropRenderNode);
        canvas.restore();
    }

    private void drawSurface(Canvas canvas, int w, int h) {
        boundsRect.set(0, 0, w, h);
        surfacePaint.setColor(Color.argb(20, 255, 255, 255));
        canvas.drawRoundRect(boundsRect, cornerRadius, cornerRadius, surfacePaint);
    }

    private void drawInnerShadow(Canvas canvas, int w, int h) {
        if (innerShadowAlpha <= 0f || innerShadowRadius <= 0f) return;

        float effectiveBlur = Math.max(innerShadowRadius, 0.001f);

        boundsRect.set(0, 0, w, h);
        clipPath.reset();
        clipPath.addRoundRect(boundsRect, cornerRadius, cornerRadius, Path.Direction.CW);

        innerShadowRenderNode.setPosition(0, 0, w, h);

        RenderEffect blurEffect = RenderEffect.createBlurEffect(
            effectiveBlur, effectiveBlur,
            android.graphics.Shader.TileMode.DECAL
        );
        innerShadowRenderNode.setRenderEffect(blurEffect);
        innerShadowRenderNode.setAlpha(innerShadowAlpha);

        Canvas nodeCanvas = innerShadowRenderNode.beginRecording(w, h);

        innerShadowPaint.setColor(innerShadowColor);
        innerShadowPaint.setAlpha(255);
        nodeCanvas.save();
        clipPath.reset();
        clipPath.addRoundRect(boundsRect, cornerRadius, cornerRadius, Path.Direction.CW);
        nodeCanvas.clipPath(clipPath);
        nodeCanvas.drawRoundRect(boundsRect, cornerRadius, cornerRadius, innerShadowPaint);

        nodeCanvas.translate(innerShadowOffsetX, innerShadowOffsetY);
        nodeCanvas.drawRoundRect(boundsRect, cornerRadius, cornerRadius, innerShadowMaskPaint);
        nodeCanvas.translate(-innerShadowOffsetX, -innerShadowOffsetY);

        nodeCanvas.restore();
        innerShadowRenderNode.endRecording();

        canvas.save();
        boundsRect.set(0, 0, w, h);
        clipPath.reset();
        clipPath.addRoundRect(boundsRect, cornerRadius, cornerRadius, Path.Direction.CW);
        canvas.clipPath(clipPath);
        canvas.drawRenderNode(innerShadowRenderNode);
        canvas.restore();
    }

    private void drawHighlight(Canvas canvas, int w, int h) {
        if (highlightAlpha <= 0f || highlightWidth <= 0f) return;

        float angleRad = (float)(highlightAngle * Math.PI / 180.0);
        highlightShader.setFloatUniform("size", (float) w, (float) h);
        highlightShader.setFloatUniform("cornerRadii", cornerRadius, cornerRadius, cornerRadius, cornerRadius);
        highlightShader.setColorUniform("color", Color.WHITE);
        highlightShader.setFloatUniform("angle", angleRad);
        highlightShader.setFloatUniform("falloff", highlightFalloff);

        highlightPaint.setColor(Color.WHITE);
        highlightPaint.setAlpha((int)(highlightAlpha * 255));
        highlightPaint.setStrokeWidth((float) Math.ceil(highlightWidth) * 2f);
        highlightPaint.setShader(highlightShader);
        highlightPaint.setStyle(Paint.Style.STROKE);

        if (highlightBlurRadius > 0f) {
            highlightPaint.setMaskFilter(new BlurMaskFilter(highlightBlurRadius, BlurMaskFilter.Blur.NORMAL));
        } else {
            highlightPaint.setMaskFilter(null);
        }

        int nodeW = w + 2;
        int nodeH = h + 2;
        highlightRenderNode.setPosition(0, 0, nodeW, nodeH);

        Canvas nodeCanvas = highlightRenderNode.beginRecording(nodeW, nodeH);
        boundsRect.set(1, 1, w + 1, h + 1);
        clipPath.reset();
        clipPath.addRoundRect(boundsRect, cornerRadius, cornerRadius, Path.Direction.CW);
        nodeCanvas.save();
        nodeCanvas.clipPath(clipPath);
        nodeCanvas.drawRoundRect(boundsRect, cornerRadius, cornerRadius, highlightPaint);
        nodeCanvas.restore();
        highlightRenderNode.endRecording();

        canvas.save();
        canvas.translate(-1f, -1f);
        canvas.drawRenderNode(highlightRenderNode);
        canvas.restore();

        highlightPaint.setShader(null);
    }

    private ColorMatrix createColorControlsMatrix(float brightness, float contrast, float saturation) {
        float invSat = 1f - saturation;
        float r = 0.213f * invSat;
        float g = 0.715f * invSat;
        float b = 0.072f * invSat;
        float c = contrast;
        float t = (0.5f - c * 0.5f + brightness) * 255f;
        float s = saturation;
        float cr = c * r;
        float cg = c * g;
        float cb = c * b;
        float cs = c * s;

        return new ColorMatrix(new float[]{
            cr + cs, cg,      cb,      0f, t,
            cr,      cg + cs, cb,      0f, t,
            cr,      cg,      cb + cs, 0f, t,
            0f,      0f,      0f,      1f, 0f
        });
    }

    public void refreshBackdrop() {
        invalidate();
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (backdropBitmap != null) {
            backdropBitmap.recycle();
            backdropBitmap = null;
            backdropCanvas = null;
        }
    }
}
